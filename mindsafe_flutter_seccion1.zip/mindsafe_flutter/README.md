# MindSafe (Flutter) — Sección 1: Base del proyecto

Esta es la **primera entrega** del proyecto Flutter de MindSafe Ecuador. Replica en Flutter
el prototipo web (`index.html`) que ya tenías: mismo diseño, mismos colores, mismos textos
y la misma lógica de SafeBot (chatbot por palabras clave).

## ✅ Qué incluye esta sección

- Estructura base del proyecto (`lib/`).
- Tema y paleta de colores (`lib/theme/app_theme.dart`), portada 1:1 de las variables CSS
  del prototipo (`--azul`, `--teal`, `--rojo`, etc.), con soporte inicial para modo claro/oscuro.
- Navegación inferior con 3 pestañas (`Inicio`, `SafeBot`, `Recursos`) — `lib/main.dart`.
- **Pantalla Inicio** (`lib/screens/home_screen.dart`): caja de crisis, reto del día,
  chips para preguntar directo al bot, dato rápido, botón de chat y botón SOS (llama al 171).
- **Pantalla SafeBot / Chat** (`lib/screens/chat_screen.dart`): burbujas de chat, indicador
  "escribiendo…", respuestas rápidas, input de texto.
- **Pantalla Recursos** (`lib/screens/recursos_screen.dart`): tarjetas con líneas de ayuda
  (MSP 171, CONSEP, directorio MSP) con botones que llaman o abren enlaces.
- **Motor de SafeBot** (`lib/data/safebot_kb.dart`): base de conocimiento por palabras clave
  portada exactamente del `KB` del prototipo (presión social, vapes, ansiedad, soledad,
  alcohol, drogas, adicción, líneas de ayuda, agradecimientos) + respuestas de respaldo.

## 🚧 Qué falta (próximas secciones, como acordamos)

- [ ] Chatbot conectado a una IA real (hoy es por palabras clave, igual que el prototipo).
- [ ] Prueba emocional.
- [ ] Biblioteca educativa.
- [ ] Retos saludables con puntos y recompensas (el reto del día hoy es solo visual/local).
- [ ] Recordatorios diarios (notificaciones locales).
- [ ] Inicio de sesión y registro.
- [ ] Pantalla de perfil.
- [ ] Modo oscuro persistente con switch manual (hoy sigue el tema del sistema).
- [ ] Integración con Firebase (Auth + Firestore).
- [ ] Icono y logo personalizados.
- [ ] Generación del APK final.

## ▶️ Cómo abrir y correr el proyecto

Necesitas tener [Flutter](https://docs.flutter.dev/get-started/install) instalado (canal estable).

```bash
# 1. Entra a la carpeta del proyecto
cd mindsafe_flutter

# 2. IMPORTANTE: este paquete trae solo el código Dart (lib/).
#    Genera las carpetas nativas android/ e ios/ con:
flutter create .

# 3. Instala las dependencias
flutter pub get

# 4. Corre la app (con un emulador/dispositivo conectado)
flutter run
```

### Generar el APK

```bash
flutter build apk --release
```

El APK quedará en `build/app/outputs/flutter-apk/app-release.apk`.

## 📁 Estructura

```
mindsafe_flutter/
├── pubspec.yaml
├── analysis_options.yaml
├── lib/
│   ├── main.dart
│   ├── theme/
│   │   └── app_theme.dart
│   ├── screens/
│   │   ├── home_screen.dart
│   │   ├── chat_screen.dart
│   │   └── recursos_screen.dart
│   └── data/
│       └── safebot_kb.dart
```

---

**Siguiente paso sugerido:** login/registro + pantalla de perfil, o el motor de retos con
puntos — dime cuál prefieres y seguimos con esa sección.
