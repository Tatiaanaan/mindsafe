import 'dart:math';

/// Entrada de la base de conocimiento: un set de palabras clave (tags)
/// asociado a una o más respuestas posibles.
class _KbEntry {
  final List<String> tags;
  final List<String> respuestas;
  const _KbEntry(this.tags, this.respuestas);
}

/// Lógica de SafeBot portada 1:1 desde el `KB` / `obtenerRespuesta()` del
/// prototipo web (index.html). Es un motor por palabras clave, no una IA
/// generativa real. En una próxima sección se puede reemplazar / complementar
/// esto con una llamada a una API de IA real (ver TODO al final del archivo).
class SafeBotKB {
  SafeBotKB._();

  static final Random _rand = Random();

  static final List<_KbEntry> _kb = [
    _KbEntry(
      ['presion', 'amigos', 'insisten', 'obligan', 'fiesta', 'fiestas', 'grupo', 'encajar', 'burlan'],
      [
        'La presión de grupo es real y puede ser muy difícil de manejar. Pero recuerda: un amigo de verdad respeta cuando dices "no". Si alguien te presiona o se burla por negarte, esa persona no está pensando en tu bienestar.\n\n'
            'Algo que funciona es tener una respuesta lista: "No me provoca hoy", "Paso, gracias" o incluso inventar una excusa. No necesitas justificarte.\n\n'
            '¿Quieres practicar cómo responder en situaciones específicas?',
        'Sentir presión social es normalísimo, especialmente en fiestas. Lo importante es recordar que consumir algo no te hace más interesante ni te da más amigos reales.\n\n'
            'Una técnica útil: si alguien te ofrece algo, acepta un vaso de agua en la mano. Con algo en la mano, la gente pregunta menos.\n\n'
            '¿Hay una situación concreta que te preocupa?',
      ],
    ),
    _KbEntry(
      ['vape', 'vapes', 'vapear', 'puff', 'pod', 'cigarrillo electronico'],
      [
        'Los vapes son más peligrosos de lo que parecen. El vapor contiene nicotina (muy adictiva), metales pesados y compuestos que dañan los pulmones.\n\n'
            'En adolescentes, la nicotina afecta el desarrollo del cerebro hasta los 25 años. Los sabores dulces están diseñados para enganchar más fácilmente.\n\n'
            '¿Alguien te ofreció uno o ya estás usando?',
        'Los vapes generan adicción a la nicotina muy rápido, a veces en semanas. En Ecuador se han detectado vapes sin regulación con sustancias no declaradas.\n\n'
            'Si ya usas y quieres dejarlo, el 171 (opción 6) tiene orientación gratuita. ¿Puedo ayudarte con algo más?',
      ],
    ),
    _KbEntry(
      ['ansioso', 'ansiedad', 'angustia', 'nervioso', 'nervios', 'estres', 'agobio'],
      [
        'La ansiedad es muy incómoda. El problema es que el alcohol o sustancias solo alivian momentáneamente: después la ansiedad regresa más fuerte.\n\n'
            'Algo que funciona ahora mismo: respira lento. Inhala 4 segundos, mantén 4, exhala 6. Repite 3 veces.\n\n'
            '¿Qué está causando esa ansiedad últimamente?',
        'Sentir ansiedad no significa que estés mal. Es una respuesta normal a situaciones difíciles.\n\n'
            'Consumir sustancias para calmarla crea un ciclo peligroso. Si es frecuente, en Ecuador hay atención gratuita en centros del MSP.\n\n'
            '¿Quieres saber cómo acceder?',
      ],
    ),
    _KbEntry(
      ['olvidar', 'escapar', 'problema', 'problemas', 'familia', 'familiar', 'pelea', 'triste', 'tristeza', 'deprimido', 'depresion'],
      [
        'Entiendo que cuando estás pasando por algo difícil, quieras una salida rápida. Pero las sustancias no borran los problemas: los pausan y los devuelven multiplicados.\n\n'
            'Lo que sí ayuda es hablar. No tienes que enfrentar eso solo. ¿Me cuentas un poco más?',
        'A veces los problemas se sienten tan pesados que uno busca cualquier cosa para no pensar. Te escucho y no te juzgo.\n\n'
            'Hablar libera ese peso mucho más que cualquier sustancia. ¿Qué está pasando? Estoy aquí.',
      ],
    ),
    _KbEntry(
      ['solo', 'soledad', 'sola', 'nadie', 'sin amigos', 'incomprendido'],
      [
        'Sentirse solo es de las sensaciones más difíciles. Y a veces el grupo donde hay consumo parece el único espacio donde encajas.\n\n'
            'Pero esa conexión basada en consumir juntos es frágil. La amistad real se construye en cosas verdaderas.\n\n'
            '¿Hay algún interés tuyo donde puedas conocer gente diferente?',
        'No estás solo/a, aunque ahora se sienta así. Muchas personas pasan por momentos así.\n\n'
            'Estoy aquí para escucharte. ¿Qué ha pasado últimamente?',
      ],
    ),
    _KbEntry(
      ['alcohol', 'tomar', 'trago', 'tragos', 'borracho', 'cerveza', 'ron', 'aguardiente'],
      [
        'El alcohol es la sustancia más normalizada en Ecuador, lo que lo hace especialmente peligroso. En adolescentes afecta directamente la memoria, emociones y toma de decisiones.\n\n'
            'La diferencia está en el por qué lo haces. ¿Estás bebiendo tú o alguien cercano te preocupa?',
        'En fiestas hay formas de estar sin tomar: pedir agua con gas, cola, o decir que no bebes hoy. La mayoría no insiste más de una vez.\n\n'
            'Si sientes que necesitas beber para sentirte bien, vale la pena hablar con alguien. ¿Cómo te sientes?',
      ],
    ),
    _KbEntry(
      ['droga', 'drogas', 'marihuana', 'weed', 'hierba', 'coca', 'cocaina', 'pasta', 'pastillas', 'extasis'],
      [
        'Es valiente que busques información. Las drogas ilegales tienen riesgos serios: no sabes qué contienen, generan dependencia y pueden tener consecuencias graves.\n\n'
            'Puedes llamar al 171 (opción 6) de forma gratuita y confidencial. ¿Qué está pasando exactamente?',
        'Hablar de esto es el primer paso. Las drogas afectan el cerebro joven de forma diferente al adulto.\n\n'
            'No tienes que decidir solo/a. ¿Sientes presión para consumir o ya estás usando y quieres orientación?',
      ],
    ),
    _KbEntry(
      ['adiccion', 'adicto', 'adicta', 'enganchado', 'no puedo parar', 'dependencia'],
      [
        'Reconocer que tienes un problema es un paso enorme y muy valiente. La adicción es una condición de salud que tiene tratamiento.\n\n'
            'En Ecuador, el MSP ofrece atención gratuita. Llama al 171 (opción 6) con total confidencialidad.\n\n'
            '¿Quieres que te cuente cómo funciona pedir ayuda?',
      ],
    ),
    _KbEntry(
      ['171', 'ayuda', 'medico', 'psicologo', 'terapia', 'centro', 'hospital'],
      [
        'El 171 (opción 6) es la línea del MSP Ecuador. Es gratuita, confidencial y disponible las 24 horas. No te van a juzgar.\n\n'
            'También puedes ir a cualquier Centro de Salud del MSP con tu cédula. La atención es gratuita.\n\n'
            '¿Quieres más información?',
      ],
    ),
    _KbEntry(
      ['gracias', 'genial', 'bien', 'me ayudo', 'entiendo', 'ok', 'chevere'],
      [
        'Me alegra poder ayudarte 😊 Recuerda que puedes volver cuando quieras. Y si necesitas hablar con alguien real, el 171 (opción 6) siempre está disponible. ¡Cuídate mucho!',
        '¡Qué bueno! Para eso estoy 🙌 Pedir ayuda o información nunca es señal de debilidad, es lo más inteligente que puedes hacer.',
      ],
    ),
  ];

  static const List<String> _fallbacks = [
    'Te escucho. Cuéntame más sobre lo que estás viviendo, así puedo orientarte mejor. Aquí estás seguro/a.',
    'Para darte la mejor respuesta, ¿puedes contarme un poco más sobre la situación?',
    'Estoy aquí contigo. No hay prisa, cuéntame lo que puedas.',
    'Eso suena importante. ¿Puedes contarme más sobre lo que está pasando?',
  ];

  static int _fallbackIndex = 0;

  static String _normalizar(String texto) {
    var t = texto.toLowerCase();
    const acentos = {
      'á': 'a', 'à': 'a', 'ä': 'a',
      'é': 'e', 'è': 'e', 'ë': 'e',
      'í': 'i', 'ì': 'i', 'ï': 'i',
      'ó': 'o', 'ò': 'o', 'ö': 'o',
      'ú': 'u', 'ù': 'u', 'ü': 'u',
      'ñ': 'n',
    };
    acentos.forEach((k, v) => t = t.replaceAll(k, v));
    return t;
  }

  /// Devuelve una respuesta de SafeBot para el [texto] del usuario,
  /// igual que `obtenerRespuesta()` en el prototipo web.
  static String obtenerRespuesta(String texto) {
    final t = _normalizar(texto);
    for (final entry in _kb) {
      if (entry.tags.any((tag) => t.contains(tag))) {
        return entry.respuestas[_rand.nextInt(entry.respuestas.length)];
      }
    }
    final resp = _fallbacks[_fallbackIndex % _fallbacks.length];
    _fallbackIndex++;
    return resp;
  }

  // TODO (próxima sección): reemplazar/complementar obtenerRespuesta() con
  // una llamada real a una API de IA (ej. vía backend propio) manteniendo
  // este KB como respaldo offline / de baja latencia.
}
