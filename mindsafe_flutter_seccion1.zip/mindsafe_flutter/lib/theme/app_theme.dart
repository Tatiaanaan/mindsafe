import 'package:flutter/material.dart';

/// Paleta de colores portada 1:1 desde las variables CSS del prototipo web
/// (:root { --azul, --teal, --rojo, ... }) para mantener consistencia visual.
class AppColors {
  AppColors._();

  static const azul = Color(0xFF1E3A8A);
  static const azulClaro = Color(0xFF2563EB);
  static const azulTenue = Color(0xFFDBEAFE);

  static const teal = Color(0xFF0F766E);
  static const tealTenue = Color(0xFFCCFBF1);
  static const tealOscuro = Color(0xFF134E4A);

  static const rojo = Color(0xFFDC2626);
  static const rojoTenue = Color(0xFFFEE2E2);
  static const rojoTexto = Color(0xFF991B1B);

  static const amarilloTenue = Color(0xFFFEF9C3);
  static const amarillo = Color(0xFFCA8A04);
  static const amarilloTexto = Color(0xFF78350F);
  static const amarilloBorde = Color(0xFFFDE68A);

  static const grisTexto = Color(0xFF475569);
  static const grisClaro = Color(0xFFF1F5F9);
  static const borde = Color(0xFFE2E8F0);

  static const blanco = Color(0xFFFFFFFF);
  static const fondo = Color(0xFFF8FAFC);
  static const fondoOscuroApp = Color(0xFF0F172A); // fondo detrás del "phone" en el prototipo

  // Modo oscuro (se amplía en próxima sección "Modo oscuro")
  static const fondoDark = Color(0xFF0F172A);
  static const superficieDark = Color(0xFF1E293B);
  static const bordeDark = Color(0xFF334155);
}

class AppTheme {
  AppTheme._();

  static ThemeData light() {
    return ThemeData(
      useMaterial3: true,
      scaffoldBackgroundColor: AppColors.fondo,
      colorScheme: ColorScheme.fromSeed(
        seedColor: AppColors.azulClaro,
        primary: AppColors.azulClaro,
        secondary: AppColors.teal,
        error: AppColors.rojo,
        surface: AppColors.blanco,
        brightness: Brightness.light,
      ),
      fontFamily: 'System',
      appBarTheme: const AppBarTheme(
        backgroundColor: AppColors.blanco,
        foregroundColor: AppColors.azul,
        elevation: 0,
        surfaceTintColor: Colors.transparent,
      ),
      navigationBarTheme: NavigationBarThemeData(
        backgroundColor: AppColors.blanco,
        indicatorColor: AppColors.azulTenue,
        labelTextStyle: WidgetStateProperty.resolveWith((states) {
          final selected = states.contains(WidgetState.selected);
          return TextStyle(
            fontSize: 10.5,
            fontWeight: FontWeight.w600,
            color: selected ? AppColors.azulClaro : const Color(0xFF94A3B8),
          );
        }),
      ),
    );
  }

  static ThemeData dark() {
    return ThemeData(
      useMaterial3: true,
      scaffoldBackgroundColor: AppColors.fondoDark,
      colorScheme: ColorScheme.fromSeed(
        seedColor: AppColors.azulClaro,
        primary: AppColors.azulClaro,
        secondary: AppColors.teal,
        error: AppColors.rojo,
        surface: AppColors.superficieDark,
        brightness: Brightness.dark,
      ),
      appBarTheme: const AppBarTheme(
        backgroundColor: AppColors.superficieDark,
        foregroundColor: Colors.white,
        elevation: 0,
        surfaceTintColor: Colors.transparent,
      ),
      navigationBarTheme: NavigationBarThemeData(
        backgroundColor: AppColors.superficieDark,
        indicatorColor: AppColors.azul,
        labelTextStyle: WidgetStateProperty.resolveWith((states) {
          final selected = states.contains(WidgetState.selected);
          return TextStyle(
            fontSize: 10.5,
            fontWeight: FontWeight.w600,
            color: selected ? Colors.white : const Color(0xFF64748B),
          );
        }),
      ),
    );
  }
}
