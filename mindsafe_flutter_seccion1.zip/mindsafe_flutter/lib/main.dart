import 'package:flutter/material.dart';
import 'theme/app_theme.dart';
import 'screens/home_screen.dart';
import 'screens/chat_screen.dart';
import 'screens/recursos_screen.dart';

void main() {
  runApp(const MindSafeApp());
}

class MindSafeApp extends StatelessWidget {
  const MindSafeApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'MindSafe',
      debugShowCheckedModeBanner: false,
      theme: AppTheme.light(),
      darkTheme: AppTheme.dark(),
      // El selector de modo oscuro real (persistente) se agrega en la
      // sección "Modo oscuro". Por ahora sigue el tema del sistema.
      themeMode: ThemeMode.system,
      home: const RootShell(),
    );
  }
}

/// Contenedor raíz con navegación inferior (Inicio / SafeBot / Recursos),
/// equivalente al <nav class="nav-bar"> + cambiarPantalla() del prototipo.
class RootShell extends StatefulWidget {
  const RootShell({super.key});

  @override
  State<RootShell> createState() => _RootShellState();
}

class _RootShellState extends State<RootShell> {
  int _index = 0;
  String? _preguntaPendiente;

  void _irAPantalla(int i) => setState(() => _index = i);

  void _preguntarDirecto(String pregunta) {
    setState(() {
      _preguntaPendiente = pregunta;
      _index = 1; // pestaña SafeBot
    });
  }

  @override
  Widget build(BuildContext context) {
    final pantallas = [
      HomeScreen(
        onPreguntarDirecto: _preguntarDirecto,
        onIrAlChat: () => _irAPantalla(1),
      ),
      ChatScreen(
        preguntaPendiente: _preguntaPendiente,
        onPreguntaPendienteConsumida: () => setState(() => _preguntaPendiente = null),
      ),
      RecursosScreen(onIrAlChat: () => _irAPantalla(1)),
    ];

    return Scaffold(
      body: IndexedStack(index: _index, children: pantallas),
      bottomNavigationBar: NavigationBar(
        selectedIndex: _index,
        onDestinationSelected: _irAPantalla,
        height: 58,
        destinations: const [
          NavigationDestination(icon: Text('🏠', style: TextStyle(fontSize: 20)), label: 'Inicio'),
          NavigationDestination(icon: Text('💬', style: TextStyle(fontSize: 20)), label: 'SafeBot'),
          NavigationDestination(icon: Text('📋', style: TextStyle(fontSize: 20)), label: 'Recursos'),
        ],
      ),
    );
  }
}
