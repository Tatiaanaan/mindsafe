import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';
import '../theme/app_theme.dart';

class RecursosScreen extends StatelessWidget {
  final VoidCallback onIrAlChat;
  const RecursosScreen({super.key, required this.onIrAlChat});

  Future<void> _abrir(String url) async {
    final uri = Uri.parse(url);
    if (await canLaunchUrl(uri)) {
      await launchUrl(uri, mode: LaunchMode.externalApplication);
    }
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: SingleChildScrollView(
        padding: const EdgeInsets.fromLTRB(16, 18, 16, 8),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('📋 Recursos de ayuda', style: TextStyle(color: AppColors.azul, fontSize: 18, fontWeight: FontWeight.bold)),
            const SizedBox(height: 2),
            const Text('Líneas de apoyo y centros de ayuda en Ecuador', style: TextStyle(color: AppColors.grisTexto, fontSize: 12)),
            const SizedBox(height: 12),

            _RecursoCard(
              titulo: '🚨 Línea de crisis · MSP Ecuador',
              descripcion: 'Ministerio de Salud Pública. Atención gratuita 24/7 para crisis emocionales, adicciones y salud mental.',
              textoBoton: 'Llamar al 171 · Opción 6',
              color: AppColors.rojo,
              onTap: () => _abrir('tel:171'),
            ),
            const SizedBox(height: 12),
            _RecursoCard(
              titulo: '📞 Consejo Nacional de Control de Sustancias',
              descripcion: 'CONSEP Ecuador. Orientación sobre prevención y tratamiento de consumo de drogas.',
              textoBoton: 'Llamar al 1-800-DROGASNO',
              color: AppColors.azulClaro,
              onTap: () => _abrir('tel:18002737726'),
            ),
            const SizedBox(height: 12),
            _RecursoCard(
              titulo: '🏥 Centro de Salud más cercano',
              descripcion: 'Los centros del MSP ofrecen atención en salud mental gratuita. Busca el más cercano a tu ubicación.',
              textoBoton: 'Ver directorio MSP',
              color: AppColors.teal,
              onTap: () => _abrir('https://www.salud.gob.ec'),
            ),
            const SizedBox(height: 12),
            _RecursoCard(
              titulo: '💬 Habla con SafeBot ahora',
              descripcion: 'Si no estás listo para llamar, puedes hablar de forma anónima con SafeBot primero. Siempre disponible.',
              textoBoton: 'Ir al chat',
              color: AppColors.azulClaro,
              onTap: onIrAlChat,
            ),
          ],
        ),
      ),
    );
  }
}

class _RecursoCard extends StatelessWidget {
  final String titulo;
  final String descripcion;
  final String textoBoton;
  final Color color;
  final VoidCallback onTap;

  const _RecursoCard({
    required this.titulo,
    required this.descripcion,
    required this.textoBoton,
    required this.color,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: AppColors.blanco,
        border: Border.all(color: AppColors.borde),
        borderRadius: BorderRadius.circular(12),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(titulo, style: const TextStyle(fontSize: 13, fontWeight: FontWeight.bold, color: Color(0xFF1E293B))),
          const SizedBox(height: 4),
          Text(descripcion, style: const TextStyle(fontSize: 12, color: AppColors.grisTexto, height: 1.45)),
          const SizedBox(height: 10),
          SizedBox(
            width: double.infinity,
            child: ElevatedButton(
              onPressed: onTap,
              style: ElevatedButton.styleFrom(
                backgroundColor: color,
                foregroundColor: Colors.white,
                padding: const EdgeInsets.symmetric(vertical: 8),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                elevation: 0,
              ),
              child: Text(textoBoton, style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w600)),
            ),
          ),
        ],
      ),
    );
  }
}
