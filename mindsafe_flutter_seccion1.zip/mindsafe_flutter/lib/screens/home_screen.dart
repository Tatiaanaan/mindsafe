import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';
import '../theme/app_theme.dart';

class HomeScreen extends StatefulWidget {
  final void Function(String pregunta) onPreguntarDirecto;
  final VoidCallback onIrAlChat;

  const HomeScreen({
    super.key,
    required this.onPreguntarDirecto,
    required this.onIrAlChat,
  });

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  bool _retoCompletado = false;

  static const _chips = [
    ('🙋 Presión social', 'Mis amigos me presionan para tomar o fumar en las fiestas'),
    ('💭 Ansiedad y emociones', 'Siento ansiedad y consumo cosas para olvidar mis problemas'),
    ('🚬 Riesgos de vapes', '¿Qué tan peligrosos son los vapes?'),
    ('🔍 ¿Tengo un problema?', '¿Cómo sé si tengo un problema con el consumo?'),
    ('😔 Me siento solo', 'Me siento solo y no sé con quién hablar'),
  ];

  Future<void> _llamar171() async {
    final uri = Uri(scheme: 'tel', path: '171');
    if (await canLaunchUrl(uri)) {
      await launchUrl(uri);
    }
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: SingleChildScrollView(
        padding: const EdgeInsets.fromLTRB(16, 18, 16, 8),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'MindSafe',
              style: TextStyle(
                color: AppColors.azul,
                fontSize: 24,
                fontWeight: FontWeight.bold,
                letterSpacing: -0.5,
              ),
            ),
            const SizedBox(height: 2),
            const Text(
              'Protección contra la presión social · Ecuador',
              style: TextStyle(color: AppColors.grisTexto, fontSize: 12),
            ),
            const SizedBox(height: 12),

            // Caja de crisis
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 13, vertical: 11),
              decoration: BoxDecoration(
                color: AppColors.rojoTenue,
                borderRadius: const BorderRadius.horizontal(right: Radius.circular(10)),
                border: const Border(left: BorderSide(color: AppColors.rojo, width: 3)),
              ),
              child: const Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    '¿Presión o ansiedad en este momento?',
                    style: TextStyle(color: AppColors.rojoTexto, fontWeight: FontWeight.bold, fontSize: 12.5),
                  ),
                  SizedBox(height: 2),
                  Text(
                    'Usa el chat de abajo para hablar de forma anónima. Nadie sabrá que estás aquí.',
                    style: TextStyle(color: AppColors.rojoTexto, fontSize: 12, height: 1.5),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 12),

            // Reto del día
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(
                gradient: const LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: [AppColors.teal, AppColors.tealOscuro],
                ),
                borderRadius: BorderRadius.circular(14),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    '🎯 Reto del día: aprende a decir no',
                    style: TextStyle(color: Colors.white, fontWeight: FontWeight.w600, fontSize: 14),
                  ),
                  const SizedBox(height: 4),
                  const Text.rich(
                    TextSpan(
                      children: [
                        TextSpan(text: 'Si alguien te insiste en consumir algo, di tranquilamente: '),
                        TextSpan(text: '"Paso, hoy no me provoca."', style: TextStyle(fontStyle: FontStyle.italic)),
                        TextSpan(text: ' No necesitas dar más explicaciones.'),
                      ],
                    ),
                    style: TextStyle(color: Colors.white70, fontSize: 12, height: 1.45),
                  ),
                  const SizedBox(height: 10),
                  SizedBox(
                    width: double.infinity,
                    child: OutlinedButton(
                      onPressed: _retoCompletado ? null : () => setState(() => _retoCompletado = true),
                      style: OutlinedButton.styleFrom(
                        backgroundColor: Colors.white.withOpacity(_retoCompletado ? 0.08 : 0.15),
                        side: BorderSide(color: Colors.white.withOpacity(0.35)),
                        padding: const EdgeInsets.symmetric(vertical: 10),
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                      ),
                      child: Text(
                        _retoCompletado ? '✅ ¡Reto completado! Muy bien hecho.' : 'Marcar reto como completado',
                        style: TextStyle(
                          color: Colors.white.withOpacity(_retoCompletado ? 0.7 : 1),
                          fontSize: 12,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 12),

            const Text(
              'TOCA PARA PREGUNTAR AL SAFEBOT',
              style: TextStyle(color: AppColors.azul, fontSize: 11, fontWeight: FontWeight.w600, letterSpacing: 0.4),
            ),
            const SizedBox(height: 8),
            Wrap(
              spacing: 6,
              runSpacing: 6,
              children: _chips.map((c) {
                return ActionChip(
                  label: Text(c.$1, style: const TextStyle(color: AppColors.grisTexto, fontSize: 11.5, fontWeight: FontWeight.w500)),
                  backgroundColor: AppColors.blanco,
                  side: const BorderSide(color: AppColors.borde),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
                  onPressed: () => widget.onPreguntarDirecto(c.$2),
                );
              }).toList(),
            ),
            const SizedBox(height: 12),

            // Dato rápido
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 13, vertical: 11),
              decoration: BoxDecoration(
                color: AppColors.amarilloTenue,
                border: Border.all(color: AppColors.amarilloBorde),
                borderRadius: BorderRadius.circular(10),
              ),
              child: const Text.rich(
                TextSpan(
                  children: [
                    TextSpan(text: '💡 Dato rápido: ', style: TextStyle(color: AppColors.amarillo, fontWeight: FontWeight.bold)),
                    TextSpan(text: 'En Ecuador, la edad promedio de inicio de consumo de alcohol es 13 años. Conocer los riesgos es tu mejor defensa.'),
                  ],
                ),
                style: TextStyle(color: AppColors.amarilloTexto, fontSize: 12, height: 1.5),
              ),
            ),
            const SizedBox(height: 12),

            // CTA chat
            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                onPressed: widget.onIrAlChat,
                style: ElevatedButton.styleFrom(
                  backgroundColor: AppColors.azulClaro,
                  foregroundColor: Colors.white,
                  padding: const EdgeInsets.symmetric(vertical: 13),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                  elevation: 0,
                ),
                child: const Text('💬 Iniciar chat con SafeBot', style: TextStyle(fontSize: 13, fontWeight: FontWeight.w600)),
              ),
            ),
            const SizedBox(height: 8),

            // Botón SOS
            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                onPressed: _llamar171,
                style: ElevatedButton.styleFrom(
                  backgroundColor: AppColors.rojo,
                  foregroundColor: Colors.white,
                  padding: const EdgeInsets.symmetric(vertical: 12),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                  elevation: 0,
                ),
                child: const Text('🚨 LLAMAR AL 171 · Opción 6 · Apoyo MSP Ecuador', style: TextStyle(fontSize: 13, fontWeight: FontWeight.w600)),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
