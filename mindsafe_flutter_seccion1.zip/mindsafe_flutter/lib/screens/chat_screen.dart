import 'dart:async';
import 'package:flutter/material.dart';
import '../data/safebot_kb.dart';
import '../theme/app_theme.dart';

class ChatMessage {
  final String texto;
  final bool esUsuario;
  final bool escribiendo;
  ChatMessage({required this.texto, required this.esUsuario, this.escribiendo = false});
}

class ChatScreen extends StatefulWidget {
  /// Si viene con una pregunta pendiente (desde un chip de Inicio), se envía automáticamente.
  final String? preguntaPendiente;
  final VoidCallback onPreguntaPendienteConsumida;

  const ChatScreen({
    super.key,
    required this.preguntaPendiente,
    required this.onPreguntaPendienteConsumida,
  });

  @override
  State<ChatScreen> createState() => _ChatScreenState();
}

class _ChatScreenState extends State<ChatScreen> {
  final List<ChatMessage> _mensajes = [
    ChatMessage(
      texto: 'Hola 👋 Soy SafeBot. Aquí puedes hablar con total libertad sobre presión social, emociones o cualquier duda sobre sustancias. Todo es privado, sin juicios.',
      esUsuario: false,
    ),
  ];

  final _controller = TextEditingController();
  final _scrollController = ScrollController();
  bool _esperando = false;
  bool _mostrarRespuestasRapidas = true;

  static const _respuestasRapidas = [
    ('Presión de amigos', 'Mis amigos me presionan para tomar'),
    ('Ansiedad', 'Me siento muy ansioso'),
    ('Riesgos de vapes', '¿Qué tan peligrosos son los vapes?'),
    ('Me siento mal', 'Me siento solo y triste'),
  ];

  @override
  void initState() {
    super.initState();
    if (widget.preguntaPendiente != null && widget.preguntaPendiente!.trim().isNotEmpty) {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        _enviarTexto(widget.preguntaPendiente!);
        widget.onPreguntaPendienteConsumida();
      });
    }
  }

  @override
  void didUpdateWidget(covariant ChatScreen oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (widget.preguntaPendiente != null && widget.preguntaPendiente!.trim().isNotEmpty) {
      _enviarTexto(widget.preguntaPendiente!);
      widget.onPreguntaPendienteConsumida();
    }
  }

  void _scrollAlFinal() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (_scrollController.hasClients) {
        _scrollController.animateTo(
          _scrollController.position.maxScrollExtent,
          duration: const Duration(milliseconds: 200),
          curve: Curves.easeOut,
        );
      }
    });
  }

  void _enviarTexto(String texto) {
    final t = texto.trim();
    if (t.isEmpty || _esperando) return;

    setState(() {
      _mensajes.add(ChatMessage(texto: t, esUsuario: true));
      _mostrarRespuestasRapidas = false;
      _esperando = true;
      _mensajes.add(ChatMessage(texto: 'SafeBot está escribiendo…', esUsuario: false, escribiendo: true));
    });
    _scrollAlFinal();

    final demora = Duration(milliseconds: 800 + (700 * (DateTime.now().millisecond / 1000)).round());
    Timer(demora, () {
      if (!mounted) return;
      setState(() {
        _mensajes.removeWhere((m) => m.escribiendo);
        _mensajes.add(ChatMessage(texto: SafeBotKB.obtenerRespuesta(t), esUsuario: false));
        _esperando = false;
      });
      _scrollAlFinal();
    });
  }

  void _enviarDesdeInput() {
    final texto = _controller.text;
    _controller.clear();
    _enviarTexto(texto);
  }

  @override
  void dispose() {
    _controller.dispose();
    _scrollController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Column(
        children: [
          // Header
          Container(
            padding: const EdgeInsets.fromLTRB(16, 14, 16, 12),
            decoration: const BoxDecoration(
              color: AppColors.blanco,
              border: Border(bottom: BorderSide(color: AppColors.borde)),
            ),
            child: Row(
              children: [
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          const Text('SafeBot', style: TextStyle(fontSize: 15, fontWeight: FontWeight.bold, color: AppColors.azul)),
                          const SizedBox(width: 6),
                          Container(
                            padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                            decoration: BoxDecoration(color: const Color(0xFFDCFCE7), borderRadius: BorderRadius.circular(10)),
                            child: const Text('Privado', style: TextStyle(fontSize: 10, fontWeight: FontWeight.bold, color: Color(0xFF15803D))),
                          ),
                        ],
                      ),
                      const Text('Sin juicios · Completamente anónimo', style: TextStyle(fontSize: 11, color: Color(0xFF64748B))),
                    ],
                  ),
                ),
              ],
            ),
          ),

          // Mensajes
          Expanded(
            child: ListView.builder(
              controller: _scrollController,
              padding: const EdgeInsets.fromLTRB(14, 14, 14, 6),
              itemCount: _mensajes.length,
              itemBuilder: (context, i) {
                final m = _mensajes[i];
                return Align(
                  alignment: m.esUsuario ? Alignment.centerRight : Alignment.centerLeft,
                  child: Container(
                    margin: const EdgeInsets.only(bottom: 8),
                    constraints: BoxConstraints(maxWidth: MediaQuery.of(context).size.width * 0.86),
                    padding: const EdgeInsets.symmetric(horizontal: 13, vertical: 10),
                    decoration: BoxDecoration(
                      color: m.esUsuario ? AppColors.azulClaro : AppColors.azulTenue,
                      borderRadius: BorderRadius.only(
                        topLeft: const Radius.circular(16),
                        topRight: const Radius.circular(16),
                        bottomLeft: Radius.circular(m.esUsuario ? 16 : 3),
                        bottomRight: Radius.circular(m.esUsuario ? 3 : 16),
                      ),
                    ),
                    child: Text(
                      m.texto,
                      style: TextStyle(
                        fontSize: 13,
                        height: 1.5,
                        color: m.esUsuario ? Colors.white : const Color(0xFF1E40AF),
                        fontStyle: m.escribiendo ? FontStyle.italic : FontStyle.normal,
                      ),
                    ),
                  ),
                );
              },
            ),
          ),

          // Respuestas rápidas
          if (_mostrarRespuestasRapidas)
            Padding(
              padding: const EdgeInsets.fromLTRB(14, 6, 14, 8),
              child: Wrap(
                spacing: 5,
                runSpacing: 5,
                children: _respuestasRapidas.map((r) {
                  return OutlinedButton(
                    onPressed: () => _enviarTexto(r.$2),
                    style: OutlinedButton.styleFrom(
                      backgroundColor: AppColors.blanco,
                      side: const BorderSide(color: Color(0xFF93C5FD)),
                      foregroundColor: AppColors.azulClaro,
                      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                      minimumSize: Size.zero,
                      tapTargetSize: MaterialTapTargetSize.shrinkWrap,
                    ),
                    child: Text(r.$1, style: const TextStyle(fontSize: 11, fontWeight: FontWeight.w500)),
                  );
                }).toList(),
              ),
            ),

          // Input
          Container(
            padding: const EdgeInsets.fromLTRB(12, 8, 12, 14),
            decoration: const BoxDecoration(
              color: AppColors.blanco,
              border: Border(top: BorderSide(color: AppColors.borde)),
            ),
            child: Row(
              children: [
                Expanded(
                  child: TextField(
                    controller: _controller,
                    onSubmitted: (_) => _enviarDesdeInput(),
                    decoration: InputDecoration(
                      hintText: 'Escribe aquí...',
                      filled: true,
                      fillColor: AppColors.grisClaro,
                      contentPadding: const EdgeInsets.symmetric(horizontal: 13, vertical: 10),
                      border: OutlineInputBorder(borderRadius: BorderRadius.circular(22), borderSide: const BorderSide(color: AppColors.borde)),
                      enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(22), borderSide: const BorderSide(color: AppColors.borde)),
                      focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(22), borderSide: const BorderSide(color: Color(0xFF93C5FD))),
                    ),
                    style: const TextStyle(fontSize: 13),
                  ),
                ),
                const SizedBox(width: 8),
                InkWell(
                  onTap: _enviarDesdeInput,
                  customBorder: const CircleBorder(),
                  child: Container(
                    width: 40,
                    height: 40,
                    decoration: const BoxDecoration(color: AppColors.azulClaro, shape: BoxShape.circle),
                    child: const Icon(Icons.send, color: Colors.white, size: 18),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
